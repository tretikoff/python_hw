from setuptools import setup, find_packages

setup(
    name='tretikoffhw1',
    version='0.0.3',
    packages=find_packages('src'),
    package_dir={'': 'src'},
    url='',
    license='',
    author='Konstantin.Tretiakov',
    author_email='pukoh@mail.ru',
    description=''
)
