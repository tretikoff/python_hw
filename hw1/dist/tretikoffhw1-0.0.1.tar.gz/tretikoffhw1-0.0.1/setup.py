from setuptools import setup

setup(
    name='tretikoffhw1',
    version='0.0.1',
    packages=[''],
    url='',
    license='',
    author='Konstantin.Tretiakov',
    author_email='pukoh@mail.ru',
    description=''
)
